import * as React from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { DayPicker } from "react-day-picker";
import { cn } from "@/lib/utils";
import { buttonVariants } from "@/components/ui/button";
function Calendar({
  className,
  classNames,
  showOutsideDays = true,
  ...props
}) {
  return <DayPicker showOutsideDays={showOutsideDays} className={cn("p-3", className)} classNames={{
    months: "flex flex-col sm:flex-row gap-4",
    month: "space-y-4",
    month_caption: "flex justify-center pt-1 relative items-center",
    caption_label: "text-sm font-medium",
    nav: "flex items-center gap-1",
    button_previous: cn(buttonVariants({
      variant: "outline"
    }), "absolute left-1 top-1 h-7 w-7 bg-transparent p-0 opacity-50 hover:opacity-100"),
    button_next: cn(buttonVariants({
      variant: "outline"
    }), "absolute right-1 top-1 h-7 w-7 bg-transparent p-0 opacity-50 hover:opacity-100"),
    month_grid: "w-full border-collapse space-y-1",
    weekdays: "flex",
    weekday: "text-muted-foreground rounded-md w-9 font-normal text-[0.8rem]",
    week: "flex w-full mt-2",
    day: "h-9 w-9 text-center text-sm p-0 relative focus-within:relative focus-within:z-20",
    day_button: cn(buttonVariants({
      variant: "ghost"
    }), "h-9 w-9 p-0 font-normal aria-selected:opacity-100"),
    range_end: "day-range-end",
    selected: "bg-primary text-primary-foreground hover:bg-primary hover:text-primary-foreground focus:bg-primary focus:text-primary-foreground",
    today: "bg-accent text-accent-foreground",
    outside: "day-outside text-muted-foreground opacity-50",
    disabled: "text-muted-foreground opacity-50",
    range_middle: "aria-selected:bg-accent aria-selected:text-accent-foreground",
    hidden: "invisible",
    ...classNames
  }} components={{
    Chevron: ({
      orientation
    }) => orientation === "left" ? <ChevronLeft className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />
  }} {...props} />;
}
Calendar.displayName = "Calendar";
export { Calendar };